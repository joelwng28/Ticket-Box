/* MULTITHREADING <MyClass.java>
 * EE422C Project 6 submission by
 * Replace <...> with your actual data.
 * Zi Zhou Wang
 * zw3948
 * 76175
 * Slip days used: <0>
 * Summer 2017
 */

package assignment6;
